import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Animated } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius, Shadows } from '../../constants/theme';
import StoreCardCompact from '../../components/StoreCardCompact';
import Button from '../../components/Button';
import { stores } from '../../constants/mockData';

export default function FavoritesScreen() {
  const router = useRouter();
  const [favoriteStores, setFavoriteStores] = useState(stores.filter(s => s.isFeatured));
  const [selectedFilter, setSelectedFilter] = useState('all');

  const filters = [
    { id: 'all', name: 'Todos', icon: 'heart' },
    { id: 'stores', name: 'Lojas', icon: 'storefront' },
    { id: 'products', name: 'Produtos', icon: 'cube' },
    { id: 'services', name: 'Serviços', icon: 'scissors' },
  ];

  const allStores = stores.filter(s => s.isFeatured);
  
  const filteredStores = selectedFilter === 'all' 
    ? favoriteStores 
    : selectedFilter === 'stores'
    ? favoriteStores.filter(s => s.tags?.includes('Pet Shop') || s.tags?.includes('Veterinária'))
    : selectedFilter === 'products'
    ? favoriteStores.filter(s => s.tags?.includes('Produtos'))
    : favoriteStores.filter(s => s.tags?.includes('Banho e Tosa') || s.tags?.includes('Serviços'));

  const handleRemoveFavorite = (storeId) => {
    setFavoriteStores(prev => prev.filter(store => store.id !== storeId));
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={[styles.headerGradient, { backgroundColor: Colors.backgroundLight }]}>
        <View style={styles.header}>
          <View style={styles.headerTop}>
            <View style={[styles.headerIcon, { backgroundColor: Colors.error + '15' }]}>
              <Ionicons name="heart" size={28} color={Colors.error} />
            </View>
            <View style={styles.headerTextContainer}>
              <Text style={styles.headerTitle}>Meus Favoritos</Text>
              <Text style={styles.headerSubtitle}>
                {favoriteStores.length} {favoriteStores.length === 1 ? 'item' : 'itens'} salvos
              </Text>
            </View>
          </View>
        </View>
      </View>

      <View style={styles.filtersContainer}>
        {filters.map((filter) => (
          <TouchableOpacity
            key={filter.id}
            style={[
              styles.filterChip,
              selectedFilter === filter.id && styles.filterChipActive
            ]}
            onPress={() => setSelectedFilter(filter.id)}
            activeOpacity={0.8}
          >
            <Ionicons 
              name={filter.icon} 
              size={18} 
              color={selectedFilter === filter.id ? Colors.textLight : Colors.textSecondary} 
            />
            <Text style={[
              styles.filterText,
              selectedFilter === filter.id && styles.filterTextActive
            ]}>
              {filter.name}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {filteredStores.length > 0 ? (
        <FlatList
          data={filteredStores}
          keyExtractor={(item) => item.id}
          numColumns={2}
          columnWrapperStyle={styles.row}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          renderItem={({ item, index }) => (
            <Animated.View style={{ flex: 1, maxWidth: '48%' }}>
              <StoreCardCompact
                store={item}
                onPress={() => router.push(`/store/${item.id}`)}
              />
            </Animated.View>
          )}
        />
      ) : (
        <View style={styles.emptyState}>
          <View style={[styles.emptyIconContainer, { backgroundColor: Colors.error + '10' }]}>
            <Ionicons name="heart-outline" size={60} color={Colors.error} />
          </View>
          <Text style={styles.emptyTitle}>Nenhum favorito ainda</Text>
          <Text style={styles.emptySubtitle}>
            Favorite suas lojas e produtos preferidos {'\n'}
            para acessá-las rapidamente aqui
          </Text>
          <Button
            title="Explorar lojas"
            variant="primary"
            onPress={() => router.push('/(tabs)')}
            style={styles.emptyButton}
          />
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  headerGradient: {
    paddingBottom: Spacing.lg,
  },
  header: {
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.md,
  },
  headerTop: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
  },
  headerIcon: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: Colors.primary + '20',
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadows.small,
  },
  headerTextContainer: {
    flex: 1,
  },
  headerTitle: {
    fontSize: FontSizes.xxl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    marginBottom: 2,
  },
  headerSubtitle: {
    fontSize: FontSizes.md,
    color: Colors.textSecondary,
  },
  filtersContainer: {
    flexDirection: 'row',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
    gap: Spacing.xs,
    flexWrap: 'wrap',
  },
  filterChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
    backgroundColor: Colors.backgroundLight,
    gap: 4,
    borderWidth: 1.5,
    borderColor: Colors.border,
  },
  filterChipActive: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
  },
  filterText: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.semibold,
    color: Colors.textSecondary,
  },
  filterTextActive: {
    color: Colors.textLight,
  },
  row: {
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.md,
    gap: Spacing.sm,
  },
  scrollContent: {
    paddingHorizontal: Spacing.md,
    paddingTop: Spacing.sm,
    paddingBottom: Spacing.xl,
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: Spacing.xl,
  },
  emptyIconContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.xl,
    ...Shadows.medium,
  },
  emptyTitle: {
    fontSize: FontSizes.xxl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    marginBottom: Spacing.sm,
    textAlign: 'center',
  },
  emptySubtitle: {
    fontSize: FontSizes.md,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: Spacing.xl,
  },
  emptyButton: {
    minWidth: 180,
  },
});
