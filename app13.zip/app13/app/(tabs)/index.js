import React, { useState, useRef } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import Animated, {
  useAnimatedScrollHandler,
  useSharedValue,
} from 'react-native-reanimated';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Colors, Spacing, FontSizes, FontWeights } from '../../constants/theme';
import GlassyHeader from '../../components/GlassyHeader';
import SearchCommandBar from '../../components/SearchCommandBar';
import PersonalizedHero from '../../components/PersonalizedHero';
import FloatingActionDock from '../../components/FloatingActionDock';
import SmartCarousel from '../../components/SmartCarousel';
import CategoryGridPremium from '../../components/CategoryGridPremium';
import StoreCardWorldClass from '../../components/StoreCardWorldClass';
import LiveTrackerWidget from '../../components/LiveTrackerWidget';
import LoyaltyCard from '../../components/LoyaltyCard';
import SectionHeader from '../../components/SectionHeader';
import SpecialOffersSection from '../../components/SpecialOffersSection';
import FeaturedProductsSection from '../../components/FeaturedProductsSection';
import PopularServicesSection from '../../components/PopularServicesSection';
import TestimonialsSection from '../../components/TestimonialsSection';
import StatisticsSection from '../../components/StatisticsSection';
import BenefitsSection from '../../components/BenefitsSection';
import HowItWorksSection from '../../components/HowItWorksSection';
import EmergencyVetSection from '../../components/EmergencyVetSection';
import { banners, categories, stores } from '../../constants/mockData';
import { useResponsiveLayout } from '../../hooks/useResponsiveLayout';

const AnimatedScrollView = Animated.createAnimatedComponent(ScrollView);

export default function HomeScreen() {
  const router = useRouter();
  const { spacing } = useResponsiveLayout();
  
  const [location, setLocation] = useState('Rua das Flores, 123');
  const [activeFilter, setActiveFilter] = useState('all');
  const scrollY = useSharedValue(0);

  const scrollHandler = useAnimatedScrollHandler({
    onScroll: (event) => {
      scrollY.value = event.contentOffset.y;
    },
  });

  const featuredStores = stores.filter(s => s.isFeatured);
  const nearbyStores = stores.filter(s => !s.isFeatured);

  const carouselItems = banners.map(banner => ({
    ...banner,
    badge: banner.action === 'shop' ? '🛍️ Compre agora' : '📅 Agende',
  }));

  const handleLocationPress = () => {
  };

  const handleNotificationPress = () => {
  };

  const handleSearch = (query) => {
  };

  const handleFilterChange = (filter) => {
    setActiveFilter(filter);
  };

  const handleHeroCTA = () => {
  };

  const handleQuickAction = (action) => {
  };

  const handleCarouselItemPress = (item) => {
  };

  const handleCategoryPress = (category) => {
  };

  const handleStorePress = (store) => {
    router.push(`/store/${store.id}`);
  };

  const handleTrackerPress = () => {
    router.push('/orders');
  };

  const handleLoyaltyPress = () => {
  };

  const handleOfferPress = (offer) => {
    router.push(`/product/${offer.id}`);
  };

  const handleProductPress = (product) => {
    router.push(`/product/${product.id}`);
  };

  const handleAddToCart = (product) => {
  };

  const handleServicePress = (service) => {
    router.push('/booking');
  };

  const handleEmergencyCall = () => {
  };

  const handleEmergencyChat = () => {
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <GlassyHeader
        location={location}
        onLocationPress={handleLocationPress}
        onNotificationPress={handleNotificationPress}
        scrollY={scrollY}
        hasNotification={true}
      />

      <AnimatedScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
        onScroll={scrollHandler}
        scrollEventThrottle={16}
      >
        <View style={styles.searchSection}>
          <SearchCommandBar
            onSearch={handleSearch}
            onFilterChange={handleFilterChange}
            placeholder="Buscar produtos, lojas, serviços..."
          />
        </View>

        <View style={styles.heroSection}>
          <PersonalizedHero
            userName="Pet Lover"
            title="Descubra o melhor para seu pet"
            subtitle="Produtos, serviços e cuidados especiais"
            ctaText="Explorar agora"
            onCTAPress={handleHeroCTA}
          />
        </View>

        <View style={styles.quickActionsSection}>
          <FloatingActionDock
            onActionPress={handleQuickAction}
          />
        </View>

        <View style={styles.trackerSection}>
          <LiveTrackerWidget
            onPress={handleTrackerPress}
          />
        </View>

        <View style={styles.categorySection}>
          <SectionHeader
            title="Categorias"
            subtitle="Explore nossos serviços"
            actionText=""
          />
          <CategoryGridPremium
            categories={categories}
            onCategoryPress={handleCategoryPress}
          />
        </View>

        <View style={styles.offersSection}>
          <SpecialOffersSection
            onOfferPress={handleOfferPress}
          />
        </View>

        <View style={styles.carouselSection}>
          <SmartCarousel
            items={carouselItems}
            onItemPress={handleCarouselItemPress}
            autoPlay={true}
            autoPlayInterval={4000}
          />
        </View>

        <View style={styles.productsSection}>
          <FeaturedProductsSection
            onProductPress={handleProductPress}
            onAddToCart={handleAddToCart}
          />
        </View>

        <View style={styles.loyaltySection}>
          <LoyaltyCard
            points={450}
            maxPoints={500}
            level="Gold"
            nextReward="Banho grátis"
            onPress={handleLoyaltyPress}
          />
        </View>

        <View style={styles.servicesSection}>
          <PopularServicesSection
            onServicePress={handleServicePress}
          />
        </View>

        <View style={styles.featuredStoresSection}>
          <SectionHeader
            title="Lojas em Destaque"
            subtitle="Selecionadas especialmente para você"
            actionText="Ver todas"
            onActionPress={() => console.log('See all featured')}
          />
          {featuredStores.map((store) => (
            <StoreCardWorldClass
              key={store.id}
              store={store}
              onPress={() => handleStorePress(store)}
              style={styles.storeCard}
            />
          ))}
        </View>

        <View style={styles.nearbyStoresSection}>
          <SectionHeader
            title="Perto de você"
            subtitle={`${nearbyStores.length} lojas disponíveis`}
            actionText="Ver mapa"
            onActionPress={() => console.log('View map')}
          />
          {nearbyStores.map((store) => (
            <StoreCardWorldClass
              key={store.id}
              store={store}
              onPress={() => handleStorePress(store)}
              style={styles.storeCard}
            />
          ))}
        </View>

        <View style={styles.testimonialsSection}>
          <TestimonialsSection />
        </View>

        <View style={styles.statisticsSection}>
          <StatisticsSection />
        </View>

        <View style={styles.benefitsSection}>
          <BenefitsSection />
        </View>

        <View style={styles.howItWorksSection}>
          <HowItWorksSection />
        </View>

        <View style={styles.emergencySection}>
          <EmergencyVetSection
            onCallPress={handleEmergencyCall}
            onChatPress={handleEmergencyChat}
          />
        </View>

        <View style={styles.bottomSpacing} />
      </AnimatedScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 100,
  },
  searchSection: {
    marginBottom: Spacing.md,
  },
  heroSection: {
    marginBottom: Spacing.lg,
  },
  quickActionsSection: {
    marginBottom: Spacing.lg,
  },
  trackerSection: {
    marginBottom: Spacing.xl,
    paddingHorizontal: Spacing.lg,
  },
  categorySection: {
    marginBottom: Spacing.xl,
  },
  offersSection: {
    marginBottom: Spacing.xl,
  },
  carouselSection: {
    marginBottom: Spacing.xl,
  },
  productsSection: {
    marginBottom: Spacing.xl,
  },
  loyaltySection: {
    marginBottom: Spacing.xl,
    paddingHorizontal: Spacing.lg,
  },
  servicesSection: {
    marginBottom: Spacing.xl,
  },
  featuredStoresSection: {
    marginBottom: Spacing.xl,
  },
  nearbyStoresSection: {
    marginBottom: Spacing.xl,
  },
  testimonialsSection: {
    marginBottom: Spacing.xl,
  },
  statisticsSection: {
    marginBottom: Spacing.xl,
  },
  benefitsSection: {
    marginBottom: Spacing.xl,
  },
  howItWorksSection: {
    marginBottom: Spacing.xl,
  },
  emergencySection: {
    marginBottom: Spacing.xl,
    paddingHorizontal: Spacing.lg,
  },
  storeCard: {
    marginBottom: Spacing.md,
  },
  bottomSpacing: {
    height: 80,
  },
});
