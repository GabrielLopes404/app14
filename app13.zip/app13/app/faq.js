import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius, Shadows } from '../constants/theme';

function FAQItem({ question, answer, isExpanded, onPress }) {
  return (
    <TouchableOpacity
      style={styles.faqItem}
      onPress={onPress}
      activeOpacity={0.8}
    >
      <View style={styles.faqHeader}>
        <Text style={styles.faqQuestion}>{question}</Text>
        <Ionicons
          name={isExpanded ? 'chevron-up' : 'chevron-down'}
          size={24}
          color={Colors.primary}
        />
      </View>
      {isExpanded && (
        <Text style={styles.faqAnswer}>{answer}</Text>
      )}
    </TouchableOpacity>
  );
}

export default function FAQScreen() {
  const router = useRouter();
  const [expandedId, setExpandedId] = useState(null);

  const faqs = [
    {
      id: '1',
      category: 'Pedidos',
      question: 'Como faço para rastrear meu pedido?',
      answer: 'Você pode rastrear seu pedido na aba "Pedidos" do aplicativo. Basta clicar no pedido desejado para ver o status atualizado em tempo real e a localização do entregador.',
    },
    {
      id: '2',
      category: 'Pedidos',
      question: 'Qual o prazo de entrega?',
      answer: 'O prazo de entrega varia de acordo com sua localização e disponibilidade da loja. Geralmente, entregamos em até 60 minutos. Você pode ver o prazo estimado no carrinho antes de finalizar o pedido.',
    },
    {
      id: '3',
      category: 'Pagamentos',
      question: 'Quais formas de pagamento são aceitas?',
      answer: 'Aceitamos cartões de crédito (Visa, Mastercard, Amex), cartões de débito, PIX e dinheiro. Você pode salvar seus cartões no app para compras mais rápidas.',
    },
    {
      id: '4',
      category: 'Pagamentos',
      question: 'Como funciona o programa de fidelidade?',
      answer: 'A cada compra você ganha pontos que podem ser trocados por descontos e prêmios. Quanto mais você compra, mais benefícios você recebe! Confira seus pontos na tela inicial do app.',
    },
    {
      id: '5',
      category: 'Agendamentos',
      question: 'Posso cancelar ou remarcar um agendamento?',
      answer: 'Sim! Você pode cancelar ou remarcar seus agendamentos com até 24 horas de antecedência sem custos. Acesse a aba "Pedidos" e selecione o agendamento que deseja alterar.',
    },
    {
      id: '6',
      category: 'Agendamentos',
      question: 'Como agendar um serviço de banho e tosa?',
      answer: 'Acesse a loja desejada, vá na aba "Serviços", selecione "Banho e tosa", escolha a data e horário disponível e confirme o agendamento. Você receberá uma confirmação por notificação.',
    },
    {
      id: '7',
      category: 'Conta',
      question: 'Como alterar meus dados cadastrais?',
      answer: 'Vá em "Perfil" > "Dados pessoais" e clique em editar. Você pode alterar nome, telefone, e-mail e outras informações. Não esqueça de salvar as alterações!',
    },
    {
      id: '8',
      category: 'Conta',
      question: 'Esqueci minha senha, como recupero?',
      answer: 'Na tela de login, clique em "Esqueci minha senha" e siga as instruções. Você receberá um e-mail com um link para criar uma nova senha.',
    },
    {
      id: '9',
      category: 'Produtos',
      question: 'Os produtos têm garantia?',
      answer: 'Sim! Todos os produtos vendidos têm garantia do fabricante. O prazo varia de acordo com o produto. Em caso de defeito, entre em contato com nossa central de atendimento.',
    },
    {
      id: '10',
      category: 'Produtos',
      question: 'Posso trocar ou devolver um produto?',
      answer: 'Você tem até 7 dias para trocar ou devolver produtos que não estejam de acordo. Entre em contato com a loja ou nossa central de ajuda para iniciar o processo.',
    },
  ];

  const categories = [...new Set(faqs.map(faq => faq.category))];

  const handleToggle = (id) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={styles.backButton}
          activeOpacity={0.7}
        >
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>FAQ</Text>
        <View style={styles.placeholder} />
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.intro}>
          <Text style={styles.introTitle}>Perguntas Frequentes</Text>
          <Text style={styles.introText}>
            Encontre respostas rápidas para as dúvidas mais comuns
          </Text>
        </View>

        {categories.map((category) => (
          <View key={category} style={styles.categorySection}>
            <Text style={styles.categoryTitle}>{category}</Text>
            {faqs
              .filter(faq => faq.category === category)
              .map((faq) => (
                <FAQItem
                  key={faq.id}
                  question={faq.question}
                  answer={faq.answer}
                  isExpanded={expandedId === faq.id}
                  onPress={() => handleToggle(faq.id)}
                />
              ))}
          </View>
        ))}

        <View style={styles.helpCard}>
          <Ionicons name="help-circle" size={48} color={Colors.primary} />
          <Text style={styles.helpTitle}>Ainda tem dúvidas?</Text>
          <Text style={styles.helpText}>
            Nossa equipe está pronta para ajudar você!
          </Text>
          <TouchableOpacity
            style={styles.helpButton}
            onPress={() => router.push('/help-center')}
            activeOpacity={0.8}
          >
            <Text style={styles.helpButtonText}>Falar com o suporte</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    backgroundColor: Colors.backgroundLight,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  backButton: {
    padding: Spacing.sm,
  },
  headerTitle: {
    fontSize: FontSizes.xl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    flex: 1,
    marginLeft: Spacing.md,
  },
  placeholder: {
    width: 40,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: Spacing.lg,
  },
  intro: {
    marginBottom: Spacing.xl,
  },
  introTitle: {
    fontSize: FontSizes.xxl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    marginBottom: Spacing.sm,
  },
  introText: {
    fontSize: FontSizes.md,
    color: Colors.textSecondary,
    lineHeight: 22,
  },
  categorySection: {
    marginBottom: Spacing.xl,
  },
  categoryTitle: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    marginBottom: Spacing.md,
  },
  faqItem: {
    backgroundColor: Colors.backgroundLight,
    borderRadius: BorderRadius.md,
    padding: Spacing.lg,
    marginBottom: Spacing.md,
    ...Shadows.small,
  },
  faqHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
  },
  faqQuestion: {
    flex: 1,
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
    marginRight: Spacing.md,
    lineHeight: 22,
  },
  faqAnswer: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
    lineHeight: 20,
    marginTop: Spacing.md,
    paddingTop: Spacing.md,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  helpCard: {
    backgroundColor: Colors.primary + '10',
    borderRadius: BorderRadius.lg,
    padding: Spacing.xl,
    alignItems: 'center',
    marginTop: Spacing.lg,
  },
  helpTitle: {
    fontSize: FontSizes.xl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    marginTop: Spacing.md,
    marginBottom: Spacing.sm,
  },
  helpText: {
    fontSize: FontSizes.md,
    color: Colors.textSecondary,
    textAlign: 'center',
    marginBottom: Spacing.lg,
  },
  helpButton: {
    backgroundColor: Colors.primary,
    borderRadius: BorderRadius.md,
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.md,
    ...Shadows.medium,
  },
  helpButtonText: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.bold,
    color: Colors.backgroundLight,
  },
});
