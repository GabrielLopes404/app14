/**
 * PETSGO - ONBOARDING PROFISSIONAL
 * Design sério e moderno inspirado em Petz
 * Marketplace de serviços e produtos para pets
 */

import React, { useRef, useState } from 'react';
import { View, Text, StyleSheet, Dimensions, FlatList, TouchableOpacity, StatusBar, Platform, Image } from 'react-native';
import Animated, { 
  useSharedValue, 
  useAnimatedStyle, 
  useAnimatedScrollHandler,
  interpolate,
  Extrapolate,
  runOnJS,
} from 'react-native-reanimated';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import Button from '../../components/Button';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius } from '../../constants/theme';

const { width, height } = Dimensions.get('window');
const isSmallDevice = width < 375;

// Paleta profissional e séria (inspirada em Petz)
const BRAND = {
  primary: '#4F5DFF',
  primaryDark: '#3D48CC',
  secondary: '#0F172A',
  bg: '#FFFFFF',
  bgGray: '#F8FAFC',
  text: {
    primary: '#0F172A',
    secondary: '#64748B',
    tertiary: '#94A3B8',
  },
  accent: {
    green: '#10B981',
    blue: '#3B82F6',
    orange: '#F97316',
    purple: '#8B5CF6',
  },
  border: '#E2E8F0',
};

const slides = [
  {
    id: '1',
    icon: 'storefront',
    title: 'Marketplace Completo',
    subtitle: 'para seu Pet',
    description: 'Encontre lojas, serviços veterinários, pet shops e muito mais. Tudo em um só lugar.',
    image: '🏪',
    stats: [
      { value: '500+', label: 'Lojas Parceiras' },
      { value: '50K+', label: 'Produtos' },
      { value: '1.2K+', label: 'Profissionais' },
    ],
  },
  {
    id: '2',
    icon: 'medical',
    title: 'Serviços Profissionais',
    subtitle: 'Certificados',
    description: 'Veterinários, banho e tosa, adestramento e muito mais com profissionais qualificados.',
    image: '🩺',
    benefits: [
      {
        icon: 'flash',
        color: BRAND.accent.orange,
        title: 'Agendamento Rápido',
        desc: 'Reserve em poucos cliques',
      },
      {
        icon: 'shield-checkmark',
        color: BRAND.accent.green,
        title: 'Profissionais Verificados',
        desc: 'Certificação garantida',
      },
      {
        icon: 'location',
        color: BRAND.accent.blue,
        title: 'Perto de Você',
        desc: 'Serviços na sua região',
      },
      {
        icon: 'star',
        color: BRAND.accent.purple,
        title: 'Avaliações Reais',
        desc: 'Feedbacks verificados',
      },
    ],
  },
  {
    id: '3',
    icon: 'rocket',
    title: 'Comece Agora',
    subtitle: 'É Grátis!',
    description: 'Cadastre-se e tenha acesso a ofertas exclusivas, cashback e muito mais.',
    image: '🎉',
    highlights: [
      { icon: 'pricetag', text: 'Ofertas Exclusivas' },
      { icon: 'wallet', text: 'Cashback em Compras' },
      { icon: 'gift', text: 'Programa de Fidelidade' },
    ],
  },
];

function SlideContent({ item, index, scrollX }) {
  const animatedStyle = useAnimatedStyle(() => {
    const inputRange = [
      (index - 1) * width,
      index * width,
      (index + 1) * width,
    ];

    const opacity = interpolate(
      scrollX.value,
      inputRange,
      [0, 1, 0],
      Extrapolate.CLAMP
    );

    const translateY = interpolate(
      scrollX.value,
      inputRange,
      [30, 0, -30],
      Extrapolate.CLAMP
    );

    return { 
      opacity,
      transform: [{ translateY }],
    };
  });

  return (
    <View style={styles.slide}>
      <SafeAreaView style={styles.slideContent} edges={['top']}>
        <Animated.View style={[styles.content, animatedStyle]}>
          {/* Ícone Grande */}
          <View style={styles.heroSection}>
            <Text style={styles.heroEmoji}>{item.image}</Text>
            <View style={styles.iconBadge}>
              <Ionicons name={item.icon} size={20} color={BRAND.primary} />
            </View>
          </View>

          {/* Título */}
          <View style={styles.titleSection}>
            <Text style={styles.title}>{item.title}</Text>
            <Text style={styles.subtitle}>{item.subtitle}</Text>
            <Text style={styles.description}>{item.description}</Text>
          </View>

          {/* Conteúdo Específico de Cada Slide */}
          <View style={styles.slideBody}>
            {/* Slide 1: Estatísticas */}
            {item.stats && (
              <View style={styles.statsRow}>
                {item.stats.map((stat, i) => (
                  <View key={i} style={styles.statBox}>
                    <Text style={styles.statValue}>{stat.value}</Text>
                    <Text style={styles.statLabel}>{stat.label}</Text>
                  </View>
                ))}
              </View>
            )}

            {/* Slide 2: Benefícios */}
            {item.benefits && (
              <View style={styles.benefitsGrid}>
                {item.benefits.map((benefit, i) => (
                  <View key={i} style={styles.benefitBox}>
                    <View style={[styles.benefitIconCircle, { backgroundColor: `${benefit.color}15` }]}>
                      <Ionicons name={benefit.icon} size={22} color={benefit.color} />
                    </View>
                    <Text style={styles.benefitTitle}>{benefit.title}</Text>
                    <Text style={styles.benefitDesc}>{benefit.desc}</Text>
                  </View>
                ))}
              </View>
            )}

            {/* Slide 3: Highlights */}
            {item.highlights && (
              <View style={styles.highlightsBox}>
                {item.highlights.map((highlight, i) => (
                  <View key={i} style={styles.highlightRow}>
                    <View style={styles.highlightIconBg}>
                      <Ionicons name={highlight.icon} size={18} color={BRAND.primary} />
                    </View>
                    <Text style={styles.highlightText}>{highlight.text}</Text>
                    <Ionicons name="checkmark-circle" size={20} color={BRAND.accent.green} />
                  </View>
                ))}
              </View>
            )}
          </View>
        </Animated.View>
      </SafeAreaView>
    </View>
  );
}

function PaginationDot({ index, scrollX }) {
  const animatedStyle = useAnimatedStyle(() => {
    const inputRange = [
      (index - 1) * width,
      index * width,
      (index + 1) * width,
    ];

    const dotWidth = interpolate(
      scrollX.value,
      inputRange,
      [8, 28, 8],
      Extrapolate.CLAMP
    );

    const opacity = interpolate(
      scrollX.value,
      inputRange,
      [0.3, 1, 0.3],
      Extrapolate.CLAMP
    );

    return { width: dotWidth, opacity };
  });

  return <Animated.View style={[styles.dot, animatedStyle]} />;
}

export default function IntroScreen() {
  const router = useRouter();
  const scrollX = useSharedValue(0);
  const flatListRef = useRef(null);
  const [currentIndex, setCurrentIndex] = useState(0);

  const scrollHandler = useAnimatedScrollHandler({
    onScroll: (event) => {
      scrollX.value = event.contentOffset.x;
      const index = Math.round(event.contentOffset.x / width);
      runOnJS(setCurrentIndex)(index);
    },
  });

  const handleNext = () => {
    if (currentIndex < slides.length - 1) {
      flatListRef.current?.scrollToIndex({
        index: currentIndex + 1,
        animated: true,
      });
    } else {
      router.push('/(onboarding)/signup');
    }
  };

  const handleSkip = () => {
    router.push('/(onboarding)/login');
  };

  const isLastSlide = currentIndex === slides.length - 1;

  return (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      
      {!isLastSlide && (
        <SafeAreaView style={styles.skipContainer} edges={['top']}>
          <TouchableOpacity 
            onPress={handleSkip}
            style={styles.skipButton}
            activeOpacity={0.7}
          >
            <Text style={styles.skipText}>Pular</Text>
          </TouchableOpacity>
        </SafeAreaView>
      )}

      <Animated.FlatList
        ref={flatListRef}
        data={slides}
        renderItem={({ item, index }) => (
          <SlideContent item={item} index={index} scrollX={scrollX} />
        )}
        keyExtractor={(item) => item.id}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={scrollHandler}
        scrollEventThrottle={16}
        bounces={false}
        decelerationRate="fast"
      />

      <SafeAreaView style={styles.bottomContainer} edges={['bottom']}>
        <View style={styles.pagination}>
          {slides.map((_, index) => (
            <PaginationDot key={index} index={index} scrollX={scrollX} />
          ))}
        </View>

        <View style={styles.buttonsWrapper}>
          {isLastSlide ? (
            <>
              <Button
                title="Criar Minha Conta"
                onPress={() => router.push('/(onboarding)/signup')}
                variant="primary"
                fullWidth
              />
              <TouchableOpacity
                onPress={() => router.push('/(onboarding)/login')}
                style={styles.loginButton}
                activeOpacity={0.7}
              >
                <Text style={styles.loginText}>Já tenho conta</Text>
              </TouchableOpacity>
            </>
          ) : (
            <Button
              title="Continuar"
              onPress={handleNext}
              variant="primary"
              fullWidth
            />
          )}
        </View>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  slide: {
    width: width,
    height: height,
    backgroundColor: '#FFFFFF',
  },
  slideContent: {
    flex: 1,
  },
  content: {
    flex: 1,
    paddingHorizontal: isSmallDevice ? 24 : 32,
    paddingTop: isSmallDevice ? 40 : 60,
    paddingBottom: 160,
  },

  // Hero
  heroSection: {
    alignItems: 'center',
    marginBottom: isSmallDevice ? 24 : 32,
    position: 'relative',
  },
  heroEmoji: {
    fontSize: isSmallDevice ? 80 : 96,
    marginBottom: 16,
  },
  iconBadge: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: `${BRAND.primary}15`,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    bottom: 0,
    right: width / 2 - 80,
    ...Platform.select({
      ios: {
        shadowColor: BRAND.primary,
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.2,
        shadowRadius: 8,
      },
      android: { elevation: 4 },
    }),
  },

  // Título
  titleSection: {
    alignItems: 'center',
    marginBottom: isSmallDevice ? 32 : 40,
  },
  title: {
    fontSize: isSmallDevice ? 26 : 30,
    fontWeight: '700',
    color: BRAND.text.primary,
    textAlign: 'center',
    marginBottom: 4,
    letterSpacing: -0.3,
  },
  subtitle: {
    fontSize: isSmallDevice ? 26 : 30,
    fontWeight: '700',
    color: BRAND.primary,
    textAlign: 'center',
    marginBottom: 16,
    letterSpacing: -0.3,
  },
  description: {
    fontSize: isSmallDevice ? 15 : 16,
    fontWeight: '400',
    color: BRAND.text.secondary,
    textAlign: 'center',
    lineHeight: 24,
    maxWidth: 320,
  },

  // Body
  slideBody: {
    flex: 1,
  },

  // Estatísticas
  statsRow: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 8,
  },
  statBox: {
    flex: 1,
    backgroundColor: BRAND.bgGray,
    borderRadius: 16,
    padding: isSmallDevice ? 16 : 20,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: BRAND.border,
  },
  statValue: {
    fontSize: isSmallDevice ? 22 : 24,
    fontWeight: '700',
    color: BRAND.text.primary,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    fontWeight: '500',
    color: BRAND.text.tertiary,
    textAlign: 'center',
  },

  // Benefícios
  benefitsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginTop: 8,
  },
  benefitBox: {
    width: '48%',
    backgroundColor: BRAND.bgGray,
    borderRadius: 16,
    padding: isSmallDevice ? 16 : 18,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: BRAND.border,
  },
  benefitIconCircle: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  benefitTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: BRAND.text.primary,
    textAlign: 'center',
    marginBottom: 4,
  },
  benefitDesc: {
    fontSize: 12,
    fontWeight: '400',
    color: BRAND.text.tertiary,
    textAlign: 'center',
  },

  // Highlights
  highlightsBox: {
    backgroundColor: BRAND.bgGray,
    borderRadius: 16,
    padding: isSmallDevice ? 16 : 20,
    gap: 16,
    marginTop: 8,
    borderWidth: 1,
    borderColor: BRAND.border,
  },
  highlightRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  highlightIconBg: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: `${BRAND.primary}15`,
    alignItems: 'center',
    justifyContent: 'center',
  },
  highlightText: {
    flex: 1,
    fontSize: 15,
    fontWeight: '500',
    color: BRAND.text.primary,
  },

  // Skip
  skipContainer: {
    position: 'absolute',
    top: 0,
    right: 0,
    zIndex: 10,
    paddingRight: 20,
    paddingTop: 12,
  },
  skipButton: {
    paddingVertical: 10,
    paddingHorizontal: 16,
    backgroundColor: BRAND.bgGray,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: BRAND.border,
  },
  skipText: {
    fontSize: 14,
    fontWeight: '500',
    color: BRAND.text.secondary,
  },

  // Bottom
  bottomContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: isSmallDevice ? 24 : 32,
    paddingBottom: 16,
    backgroundColor: '#FFFFFF',
  },
  pagination: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 6,
    marginBottom: 20,
  },
  dot: {
    height: 4,
    borderRadius: 2,
    backgroundColor: BRAND.primary,
  },
  buttonsWrapper: {
    gap: 12,
  },
  loginButton: {
    alignItems: 'center',
    paddingVertical: 16,
    borderRadius: 14,
    borderWidth: 1.5,
    borderColor: BRAND.border,
  },
  loginText: {
    fontSize: 16,
    fontWeight: '600',
    color: BRAND.text.secondary,
  },
});
