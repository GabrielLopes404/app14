import React, { useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withSpring,
  withTiming,
  interpolate,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Spacing, FontSizes, FontWeights, BorderRadius, Shadows, Motion } from '../constants/theme';
import { useResponsiveLayout } from '../hooks/useResponsiveLayout';

const AnimatedTouchable = Animated.createAnimatedComponent(TouchableOpacity);

export default function LoyaltyCard({
  points = 450,
  maxPoints = 500,
  level = 'Gold',
  nextReward = 'Banho grátis',
  onPress,
}) {
  const { spacing } = useResponsiveLayout();
  const progressWidth = useSharedValue(0);
  const cardScale = useSharedValue(0.95);
  const cardOpacity = useSharedValue(0);

  const progress = Math.min(points / maxPoints, 1);

  useEffect(() => {
    cardScale.value = withSpring(1, Motion.spring.gentle);
    cardOpacity.value = withTiming(1, { duration: 300 });
    
    progressWidth.value = withDelay(
      200,
      withSpring(progress, Motion.spring.smooth)
    );
  }, [progress]);

  const cardAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: cardScale.value }],
    opacity: cardOpacity.value,
  }));

  const progressAnimatedStyle = useAnimatedStyle(() => ({
    width: `${progressWidth.value * 100}%`,
  }));

  const pointsAnimatedStyle = useAnimatedStyle(() => {
    const interpolatedValue = interpolate(
      progressWidth.value,
      [0, 1],
      [0, points]
    );

    return {
      opacity: progressWidth.value,
    };
  });

  return (
    <AnimatedTouchable
      style={[styles.container, { marginHorizontal: spacing.lg }, cardAnimatedStyle]}
      activeOpacity={0.95}
      onPress={onPress}
    >
      <LinearGradient
        colors={Colors.gradientPremiumViolet}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.gradient}
      >
        <View style={[styles.content, { padding: spacing.lg }]}>
          <View style={styles.header}>
            <View style={styles.levelBadge}>
              <Ionicons name="trophy" size={16} color={Colors.accent} />
              <Text style={styles.levelText}>{level}</Text>
            </View>

            <TouchableOpacity style={styles.infoButton} activeOpacity={0.7}>
              <Ionicons name="information-circle-outline" size={20} color={Colors.textLight} />
            </TouchableOpacity>
          </View>

          <Text style={styles.title}>Programa de Fidelidade</Text>

          <View style={styles.pointsContainer}>
            <Animated.Text style={[styles.points, pointsAnimatedStyle]}>
              {points}
            </Animated.Text>
            <Text style={styles.pointsLabel}>pontos</Text>
          </View>

          <View style={styles.progressSection}>
            <View style={styles.progressBackground}>
              <Animated.View style={[styles.progressBar, progressAnimatedStyle]}>
                <LinearGradient
                  colors={['#FFFFFF', 'rgba(255, 255, 255, 0.8)']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={styles.progressGradient}
                />
              </Animated.View>
            </View>

            <View style={styles.progressInfo}>
              <Text style={styles.progressText}>
                Faltam {maxPoints - points} pts para
              </Text>
              <View style={styles.rewardBadge}>
                <Ionicons name="gift" size={14} color={Colors.accent} />
                <Text style={styles.rewardText}>{nextReward}</Text>
              </View>
            </View>
          </View>

          <View style={styles.footer}>
            <View style={styles.stat}>
              <Text style={styles.statValue}>12</Text>
              <Text style={styles.statLabel}>Compras</Text>
            </View>
            
            <View style={styles.statDivider} />
            
            <View style={styles.stat}>
              <Text style={styles.statValue}>R$ 1.240</Text>
              <Text style={styles.statLabel}>Economizado</Text>
            </View>
            
            <View style={styles.statDivider} />
            
            <View style={styles.stat}>
              <Text style={styles.statValue}>3</Text>
              <Text style={styles.statLabel}>Recompensas</Text>
            </View>
          </View>
        </View>
      </LinearGradient>
    </AnimatedTouchable>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: Spacing.xl,
    borderRadius: BorderRadius.xl,
    overflow: 'hidden',
    ...Shadows.premiumMulti,
  },
  gradient: {
    overflow: 'hidden',
  },
  content: {
    gap: Spacing.lg,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  levelBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.xl,
    gap: 6,
    ...Shadows.small,
  },
  levelText: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.extrabold,
    color: Colors.textPrimary,
  },
  infoButton: {
    width: 32,
    height: 32,
    borderRadius: BorderRadius.md,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: 'rgba(255, 255, 255, 0.9)',
  },
  pointsContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: Spacing.sm,
  },
  points: {
    fontSize: FontSizes.displayLG,
    fontWeight: FontWeights.extrabold,
    color: Colors.textLight,
    lineHeight: 48,
  },
  pointsLabel: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.medium,
    color: 'rgba(255, 255, 255, 0.8)',
  },
  progressSection: {
    gap: Spacing.sm,
  },
  progressBackground: {
    height: 12,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 6,
    overflow: 'hidden',
  },
  progressBar: {
    height: '100%',
    borderRadius: 6,
    overflow: 'hidden',
  },
  progressGradient: {
    flex: 1,
  },
  progressInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: Spacing.xs,
  },
  progressText: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.medium,
    color: 'rgba(255, 255, 255, 0.9)',
  },
  rewardBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    borderRadius: BorderRadius.sm,
    gap: 4,
  },
  rewardText: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    paddingTop: Spacing.md,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.2)',
  },
  stat: {
    alignItems: 'center',
    gap: 4,
  },
  statValue: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.bold,
    color: Colors.textLight,
  },
  statLabel: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.medium,
    color: 'rgba(255, 255, 255, 0.8)',
  },
  statDivider: {
    width: 1,
    height: 32,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
  },
});
