import React, { useState } from 'react';
import { View, TextInput, Text, StyleSheet, TouchableOpacity } from 'react-native';
import Animated, { 
  useAnimatedStyle, 
  useSharedValue, 
  withTiming,
  withSpring,
} from 'react-native-reanimated';
import { Colors, FontSizes, BorderRadius, Spacing, FontWeights, Shadows } from '../constants/theme';
import { Ionicons } from '@expo/vector-icons';

export default function Input({
  label,
  value,
  onChangeText,
  placeholder,
  secureTextEntry = false,
  keyboardType = 'default',
  error = '',
  icon = null,
  multiline = false,
  numberOfLines = 1,
  style,
}) {
  const [isFocused, setIsFocused] = useState(false);
  const [isPasswordVisible, setIsPasswordVisible] = useState(false);
  
  const borderWidth = useSharedValue(1.5);
  const borderColor = useSharedValue(Colors.border);
  const labelScale = useSharedValue(value ? 0.85 : 1);
  const labelY = useSharedValue(value ? -12 : 0);
  const shadowOpacity = useSharedValue(0);

  const animatedBorderStyle = useAnimatedStyle(() => ({
    borderWidth: borderWidth.value,
    borderColor: borderColor.value,
    shadowOpacity: shadowOpacity.value,
  }));

  const animatedLabelStyle = useAnimatedStyle(() => ({
    transform: [
      { scale: labelScale.value },
      { translateY: labelY.value },
    ],
  }));

  const handleFocus = () => {
    setIsFocused(true);
    borderWidth.value = withSpring(2);
    borderColor.value = withTiming(Colors.primary, { duration: 200 });
    shadowOpacity.value = withTiming(0.15, { duration: 200 });
    labelScale.value = withSpring(0.85);
    labelY.value = withSpring(-12);
  };

  const handleBlur = () => {
    setIsFocused(false);
    borderWidth.value = withSpring(1.5);
    borderColor.value = withTiming(error ? Colors.error : Colors.border, { duration: 200 });
    shadowOpacity.value = withTiming(0, { duration: 200 });
    if (!value) {
      labelScale.value = withSpring(1);
      labelY.value = withSpring(0);
    }
  };

  return (
    <View style={[styles.container, style]}>
      {label && (
        <Animated.View style={[styles.labelContainer, animatedLabelStyle]}>
          <Text style={[
            styles.label,
            { 
              color: isFocused ? Colors.primary : error ? Colors.error : Colors.textSecondary,
              fontWeight: isFocused ? FontWeights.semibold : FontWeights.medium,
            }
          ]}>
            {label}
          </Text>
        </Animated.View>
      )}
      
      <Animated.View style={[styles.inputContainer, animatedBorderStyle]}>
        {icon && (
          <View style={styles.iconContainer}>
            {icon}
          </View>
        )}
        
        <TextInput
          value={value}
          onChangeText={onChangeText}
          placeholder={!isFocused && !value ? placeholder : ''}
          placeholderTextColor={Colors.textTertiary}
          onFocus={handleFocus}
          onBlur={handleBlur}
          secureTextEntry={secureTextEntry && !isPasswordVisible}
          keyboardType={keyboardType}
          multiline={multiline}
          numberOfLines={numberOfLines}
          style={[
            styles.input,
            multiline && styles.multilineInput,
            icon && styles.inputWithIcon,
          ]}
        />
        
        {secureTextEntry && (
          <TouchableOpacity
            onPress={() => setIsPasswordVisible(!isPasswordVisible)}
            style={styles.eyeIcon}
            activeOpacity={0.7}
          >
            <Ionicons
              name={isPasswordVisible ? 'eye-off' : 'eye'}
              size={22}
              color={isFocused ? Colors.primary : Colors.textSecondary}
            />
          </TouchableOpacity>
        )}
      </Animated.View>
      
      {error ? (
        <Animated.View entering={{ duration: 200 }}>
          <Text style={styles.errorText}>{error}</Text>
        </Animated.View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: Spacing.lg,
  },
  labelContainer: {
    position: 'absolute',
    top: 20,
    left: Spacing.lg,
    backgroundColor: Colors.backgroundLight,
    paddingHorizontal: 6,
    zIndex: 1,
  },
  label: {
    fontSize: FontSizes.md,
    letterSpacing: 0.3,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: BorderRadius.lg,
    backgroundColor: Colors.backgroundLight,
    paddingHorizontal: Spacing.lg,
    minHeight: 60,
  },
  iconContainer: {
    marginRight: Spacing.md,
  },
  input: {
    flex: 1,
    fontSize: FontSizes.md,
    color: Colors.textPrimary,
    paddingVertical: Spacing.lg,
    fontWeight: FontWeights.medium,
  },
  inputWithIcon: {
    paddingLeft: 0,
  },
  multilineInput: {
    minHeight: 120,
    textAlignVertical: 'top',
    paddingTop: Spacing.lg,
  },
  eyeIcon: {
    padding: Spacing.sm,
    marginLeft: Spacing.sm,
  },
  errorText: {
    fontSize: FontSizes.sm,
    color: Colors.error,
    marginTop: Spacing.sm,
    marginLeft: Spacing.lg,
    fontWeight: FontWeights.medium,
  },
});
