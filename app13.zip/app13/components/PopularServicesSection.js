import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius, Shadows } from '../constants/theme';

function ServiceCard({ service, onPress }) {
  return (
    <TouchableOpacity
      style={styles.serviceCard}
      onPress={onPress}
      activeOpacity={0.95}
    >
      <Image
        source={{ uri: service.image }}
        style={styles.serviceImage}
        resizeMode="cover"
      />
      
      <View style={styles.gradient} />
      
      <View style={styles.serviceContent}>
        <View style={styles.iconContainer}>
          <Ionicons name={service.icon} size={28} color={Colors.textLight} />
        </View>
        
        <Text style={styles.serviceName}>{service.name}</Text>
        <Text style={styles.serviceDescription} numberOfLines={2}>
          {service.description}
        </Text>
        
        <View style={styles.serviceFooter}>
          <View style={styles.priceContainer}>
            <Text style={styles.priceLabel}>A partir de</Text>
            <Text style={styles.price}>R$ {service.price.toFixed(2)}</Text>
          </View>
          
          <View style={styles.statsContainer}>
            <View style={styles.stat}>
              <Ionicons name="star" size={14} color={Colors.rating} />
              <Text style={styles.statText}>{service.rating.toFixed(1)}</Text>
            </View>
            <View style={styles.stat}>
              <Ionicons name="time-outline" size={14} color={Colors.textLight} />
              <Text style={styles.statText}>{service.duration}</Text>
            </View>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
}

export default function PopularServicesSection({ services = [], onServicePress }) {
  const defaultServices = [
    {
      id: '1',
      name: 'Banho e Tosa',
      description: 'Banho completo, tosa higiênica e muito carinho',
      icon: 'water',
      price: 80.00,
      rating: 4.9,
      duration: '2h',
      image: 'https://images.unsplash.com/photo-1570458436416-b8fcccfe883e?w=500'
    },
    {
      id: '2',
      name: 'Consulta Veterinária',
      description: 'Check-up completo com veterinário experiente',
      icon: 'medical',
      price: 150.00,
      rating: 4.8,
      duration: '45min',
      image: 'https://images.unsplash.com/photo-1576201836106-db1758fd1c97?w=500'
    },
    {
      id: '3',
      name: 'Adestramento',
      description: 'Treinamento profissional para seu pet',
      icon: 'trophy',
      price: 200.00,
      rating: 4.7,
      duration: '1h',
      image: 'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=500'
    }
  ];

  const displayServices = services.length > 0 ? services : defaultServices;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>Serviços Populares</Text>
          <Text style={styles.subtitle}>Cuidado profissional para seu pet</Text>
        </View>
        <TouchableOpacity activeOpacity={0.8}>
          <Text style={styles.viewAll}>Ver todos</Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {displayServices.map((service) => (
          <ServiceCard
            key={service.id}
            service={service}
            onPress={() => onServicePress?.(service)}
          />
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: Spacing.xl,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.md,
  },
  title: {
    fontSize: FontSizes.xxl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    marginBottom: 2,
  },
  subtitle: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
  },
  viewAll: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.semibold,
    color: Colors.primary,
    marginTop: 4,
  },
  scrollContent: {
    paddingHorizontal: Spacing.lg,
    gap: Spacing.md,
  },
  serviceCard: {
    width: 280,
    height: 200,
    borderRadius: BorderRadius.xl,
    overflow: 'hidden',
    ...Shadows.medium,
  },
  serviceImage: {
    width: '100%',
    height: '100%',
    backgroundColor: Colors.backgroundGray,
  },
  gradient: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.4)',
  },
  serviceContent: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    padding: Spacing.lg,
    justifyContent: 'space-between',
  },
  iconContainer: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadows.medium,
  },
  serviceName: {
    fontSize: FontSizes.xl,
    fontWeight: FontWeights.bold,
    color: Colors.textLight,
    marginTop: 'auto',
    marginBottom: Spacing.xs,
  },
  serviceDescription: {
    fontSize: FontSizes.sm,
    color: Colors.textLight,
    opacity: 0.9,
    marginBottom: Spacing.md,
  },
  serviceFooter: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },
  priceContainer: {
    flex: 1,
  },
  priceLabel: {
    fontSize: FontSizes.xs,
    color: Colors.textLight,
    opacity: 0.8,
    marginBottom: 2,
  },
  price: {
    fontSize: FontSizes.xl,
    fontWeight: FontWeights.bold,
    color: Colors.textLight,
  },
  statsContainer: {
    gap: Spacing.xs,
  },
  stat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  statText: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.semibold,
    color: Colors.textLight,
  },
});
