import React from 'react';
import { StyleSheet } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import PressableScale from './PressableScale';
import { Colors, BorderRadius, Spacing, Shadows } from '../constants/theme';

export default function Card({ 
  children, 
  onPress, 
  style, 
  animated = true, 
  shadow = 'medium',
  elevated = false,
}) {
  const elevation = useSharedValue(0);

  const animatedStyle = useAnimatedStyle(() => ({
    shadowOffset: { width: 0, height: elevation.value },
    shadowOpacity: 0.12 + (elevation.value * 0.02),
    shadowRadius: 12 + elevation.value,
  }));

  const handlePressIn = () => {
    if (animated && onPress) {
      elevation.value = withSpring(8);
    }
  };

  const handlePressOut = () => {
    if (animated && onPress) {
      elevation.value = withSpring(0);
    }
  };

  const getShadowStyle = () => {
    switch (shadow) {
      case 'none': return {};
      case 'xs': return Shadows.xs;
      case 'small': return Shadows.small;
      case 'medium': return Shadows.medium;
      case 'large': return Shadows.large;
      default: return Shadows.medium;
    }
  };

  if (onPress) {
    return (
      <PressableScale
        onPress={onPress}
        style={[
          styles.card,
          getShadowStyle(),
          elevated && animatedStyle,
          style,
        ]}
      >
        {children}
      </PressableScale>
    );
  }

  return (
    <Animated.View style={[styles.card, getShadowStyle(), style]}>
      {children}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: Colors.backgroundLight,
    borderRadius: BorderRadius.xl,
    padding: Spacing.lg,
  },
});
