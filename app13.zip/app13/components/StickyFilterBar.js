import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Spacing, FontSizes, FontWeights, BorderRadius, Shadows } from '../constants/theme';

const FILTERS = [
  { id: 'all', label: 'Todos', icon: 'apps' },
  { id: 'fast', label: 'Mais rápido', icon: 'flash' },
  { id: 'nearby', label: 'Perto de você', icon: 'location' },
  { id: 'discount', label: 'Promoções', icon: 'pricetag' },
  { id: 'new', label: 'Novidades', icon: 'sparkles' },
  { id: 'rated', label: 'Bem avaliados', icon: 'star' },
  { id: 'open', label: 'Aberto agora', icon: 'time' },
];

const StickyFilterBar = ({ 
  activeFilter = 'all', 
  onFilterChange, 
  scrollY 
}) => {
  return (
    <View style={styles.container}>
      <View style={styles.innerContainer}>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.scrollContent}
          bounces={false}
        >
          {FILTERS.map((filter, index) => {
            const isActive = activeFilter === filter.id;
            
            return (
              <TouchableOpacity
                key={filter.id}
                onPress={() => onFilterChange(filter.id)}
                activeOpacity={0.7}
                style={[
                  styles.filterButton,
                  index === 0 && styles.firstFilter,
                ]}
              >
                {isActive ? (
                  <LinearGradient
                    colors={Colors.gradientTwilight}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                    style={styles.activeFilterGradient}
                  >
                    <Ionicons 
                      name={filter.icon} 
                      size={16} 
                      color={Colors.textLight} 
                      style={styles.filterIcon}
                    />
                    <Text style={styles.activeFilterText}>{filter.label}</Text>
                  </LinearGradient>
                ) : (
                  <View style={styles.inactiveFilter}>
                    <Ionicons 
                      name={filter.icon} 
                      size={16} 
                      color={Colors.textSecondary} 
                      style={styles.filterIcon}
                    />
                    <Text style={styles.filterText}>{filter.label}</Text>
                  </View>
                )}
              </TouchableOpacity>
            );
          })}
        </ScrollView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.backgroundLight,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.borderLight,
    ...Shadows.small,
  },
  innerContainer: {
    // No padding needed here
  },
  scrollContent: {
    paddingHorizontal: Spacing.lg,
    gap: Spacing.sm,
  },
  filterButton: {
    marginRight: Spacing.xs,
  },
  firstFilter: {
    marginLeft: 0,
  },
  activeFilterGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.round,
    minHeight: 44,
    ...Shadows.colored,
  },
  inactiveFilter: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.round,
    backgroundColor: Colors.backgroundCard,
    borderWidth: 1.5,
    borderColor: Colors.border,
    minHeight: 44,
  },
  filterIcon: {
    marginRight: Spacing.xs,
  },
  activeFilterText: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.bold,
    color: Colors.textLight,
  },
  filterText: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.textSecondary,
  },
  bottomShadow: {
    height: 0,
  },
});

export default StickyFilterBar;
