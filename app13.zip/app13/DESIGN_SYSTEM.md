# PetsGo Design System
## UI/UX Locked - November 10, 2025

Este documento define o sistema de design completo do PetsGo. **Não modificar após esta data** - serve como referência para a fase de backend.

---

## 🎨 Paleta de Cores

### Cores Primárias
```javascript
primary: '#4F5DFF'        // Roxo vibrante - Ações principais
secondary: '#7C8BFF'      // Roxo claro - Estados secundários
accent: '#00C2A8'         // Verde água - CTAs e destaques
```

### Cores de Background
```javascript
background: '#F5F6FA'     // Cinza muito claro - Background principal
backgroundLight: '#FFFFFF' // Branco - Cards e componentes
backgroundDark: '#EEEEF5' // Cinza claro - Divisores sutis
```

### Cores de Texto
```javascript
textPrimary: '#1A1D29'    // Quase preto - Textos principais
textSecondary: '#A7A7B7'  // Cinza médio - Textos secundários
textLight: '#D1D1D8'      // Cinza claro - Placeholders
```

### Cores Semânticas
```javascript
success: '#00C851'        // Verde - Sucesso, confirmações
error: '#FF4444'          // Vermelho - Erros, alertas
warning: '#FFBB33'        // Laranja - Avisos
info: '#33B5E5'           // Azul - Informações
```

### Cores de Borda
```javascript
border: '#EEEEF5'         // Cinza claro - Bordas e divisores
```

---

## 📝 Tipografia

### Tamanhos de Fonte
```javascript
xs: 11    // Labels pequenas, metadados
sm: 13    // Textos secundários, descrições
md: 15    // Textos padrão, body
lg: 17    // Subtítulos, destaques
xl: 20    // Títulos de seção
xxl: 24   // Títulos de página
xxxl: 32  // Títulos hero
```

### Pesos de Fonte (Font Weights)
```javascript
regular: '400'    // Textos normais
medium: '500'     // Ênfase leve
semibold: '600'   // Subtítulos, labels importantes
bold: '700'       // Títulos principais
extrabold: '800'  // Hero titles, CTAs especiais
```

### Hierarquia Tipográfica

**Hero Title**
- Tamanho: xxxl (32px)
- Peso: extrabold (800)
- Uso: Títulos principais, hero sections

**Page Title**
- Tamanho: xxl (24px)
- Peso: bold (700)
- Uso: Títulos de páginas, headers

**Section Title**
- Tamanho: xl (20px)
- Peso: bold (700)
- Uso: Títulos de seções

**Subtitle**
- Tamanho: lg (17px)
- Peso: semibold (600)
- Uso: Subtítulos, categorias

**Body Text**
- Tamanho: md (15px)
- Peso: regular (400)
- Uso: Textos principais, parágrafos

**Small Text**
- Tamanho: sm (13px)
- Peso: regular (400)
- Uso: Descrições, metadados

**Caption**
- Tamanho: xs (11px)
- Peso: regular (400)
- Uso: Labels pequenas, timestamps

---

## 📏 Spacing System

Baseado em múltiplos de 4px para consistência e alinhamento.

```javascript
xs: 4      // Espaçamentos mínimos
sm: 8      // Espaçamentos pequenos entre elementos
md: 12     // Espaçamento padrão entre componentes
lg: 16     // Espaçamento entre seções pequenas
xl: 24     // Espaçamento entre seções
xxl: 32    // Espaçamento entre grupos de conteúdo
xxxl: 48   // Espaçamento entre seções principais
```

### Uso Recomendado
- **xs (4px)**: Padding interno de badges, gaps mínimos
- **sm (8px)**: Gaps entre ícones e texto, padding de botões pequenos
- **md (12px)**: Margin entre elementos relacionados, padding de inputs
- **lg (16px)**: Padding de cards, margin entre componentes
- **xl (24px)**: Margin entre seções de uma página
- **xxl (32px)**: Padding de containers principais
- **xxxl (48px)**: Margin entre seções principais (hero, features, etc)

---

## 🔲 Border Radius

```javascript
xs: 4      // Elementos muito pequenos (badges)
sm: 8      // Botões, inputs pequenos
md: 12     // Botões padrão, inputs, tags
lg: 16     // Cards, modais
xl: 20     // Cards grandes, containers principais
xxl: 24    // Elementos especiais, hero sections
```

---

## 🌑 Shadows (Elevação)

### Extra Small
```javascript
shadowColor: '#000'
shadowOffset: { width: 0, height: 1 }
shadowOpacity: 0.05
shadowRadius: 2
elevation: 1
```
**Uso**: Bordas sutis, separadores

### Small
```javascript
shadowColor: '#000'
shadowOffset: { width: 0, height: 2 }
shadowOpacity: 0.08
shadowRadius: 4
elevation: 2
```
**Uso**: Cards, botões, inputs

### Medium
```javascript
shadowColor: '#000'
shadowOffset: { width: 0, height: 4 }
shadowOpacity: 0.12
shadowRadius: 8
elevation: 4
```
**Uso**: Modais, dropdowns, floating elements

### Large
```javascript
shadowColor: '#000'
shadowOffset: { width: 0, height: 8 }
shadowOpacity: 0.16
shadowRadius: 16
elevation: 8
```
**Uso**: Overlays, bottom sheets, importantes CTAs

---

## 🧩 Componentes Base

### Button
- **Primary**: Background primary, texto branco, shadow medium
- **Secondary**: Background transparent, borda primary, texto primary
- **Accent**: Background accent, texto branco, shadow medium
- **Danger**: Background error, texto branco
- Height padrão: 48px
- Border radius: md (12px)
- Padding horizontal: lg (16px)

### Input
- Background: backgroundLight
- Border: 1px border color
- Border radius: md (12px)
- Padding: md (12px) horizontal
- Height: 48px
- Focus: Border primary, shadow small

### Card
- Background: backgroundLight
- Border radius: lg (16px)
- Padding: lg (16px)
- Shadow: small
- Margin bottom: md (12px)

### Badge
- Border radius: sm (8px)
- Padding: xs-sm (4-8px)
- Font size: xs (11px)
- Font weight: semibold (600)

### Avatar
- Border radius: 50% (circular)
- Tamanhos: 32px (small), 48px (medium), 64px (large), 100px+ (profile)

### Icon Container
- Width/Height: 48px (padrão)
- Border radius: md (12px)
- Background: primary + '10' (10% opacity)
- Ícone: 24px

---

## 📱 Telas Completas

### Autenticação & Onboarding (4 telas)
✅ `/app/(onboarding)/intro.js` - Introdução animada
✅ `/app/(onboarding)/login.js` - Login
✅ `/app/(onboarding)/signup.js` - Cadastro
✅ `/app/(onboarding)/forgot-password.js` - Recuperação de senha

### Tabs Principais (4 telas)
✅ `/app/(tabs)/index.js` - Home
✅ `/app/(tabs)/orders.js` - Pedidos
✅ `/app/(tabs)/favorites.js` - Favoritos
✅ `/app/(tabs)/profile.js` - Perfil

### Navegação Principal (6 telas)
✅ `/app/store/[id].js` - Detalhes da loja
✅ `/app/product/[id].js` - Detalhes do produto
✅ `/app/cart.js` - Carrinho
✅ `/app/checkout.js` - Checkout
✅ `/app/booking.js` - Agendamento
✅ `/app/search.js` - Busca

### Pedidos (1 tela)
✅ `/app/orders/[id].js` - Detalhes do pedido

### Perfil & Configurações (9 telas)
✅ `/app/personal-data.js` - Dados pessoais
✅ `/app/addresses.js` - Endereços
✅ `/app/payment-methods.js` - Formas de pagamento
✅ `/app/notifications.js` - Central de notificações
✅ `/app/notification-settings.js` - Configurações de notificação
✅ `/app/help-center.js` - Central de ajuda
✅ `/app/faq.js` - Perguntas frequentes
✅ `/app/privacy-security.js` - Privacidade e segurança
✅ `/app/terms.js` - Termos de uso

**Total: 24 telas completas**

---

## 🔄 Fluxos de Navegação

### Fluxo de Onboarding
```
Intro → Login → Home
      ↓
   Signup → Home
      ↓
Forgot Password → Login
```

### Fluxo de Compra
```
Home → Store → Product → Cart → Checkout → Order Detail
                           ↓
                        Orders Tab
```

### Fluxo de Agendamento
```
Home → Store → Services → Booking → Confirmation → Orders
```

### Fluxo de Perfil
```
Profile → Personal Data
        → Addresses
        → Payment Methods
        → Notifications
        → Notification Settings
        → Help Center
        → FAQ
        → Privacy & Security
        → Terms
```

---

## 📂 Estrutura de Pastas

```
/app
  /(onboarding)         # Autenticação e intro
    - intro.js
    - login.js
    - signup.js
    - forgot-password.js
    - _layout.js
  
  /(tabs)               # Navegação principal
    - index.js          # Home
    - orders.js
    - favorites.js
    - profile.js
    - _layout.js
  
  /orders               # Detalhes de pedidos
    - [id].js
  
  /product              # Detalhes de produtos
    - [id].js
  
  /store                # Detalhes de lojas
    - [id].js
  
  - cart.js             # Carrinho
  - checkout.js         # Finalização
  - booking.js          # Agendamento
  - search.js           # Busca
  - notifications.js    # Notificações
  - personal-data.js    # Dados pessoais
  - addresses.js        # Endereços
  - payment-methods.js  # Pagamentos
  - help-center.js      # Ajuda
  - faq.js              # FAQ
  - notification-settings.js  # Config notificações
  - privacy-security.js # Privacidade
  - terms.js            # Termos
  - _layout.js          # Layout raiz
  - index.js            # Redirect

/components             # Componentes reutilizáveis
  - Animação (AnimatedBackground, AnimatedGradient, PressableScale)
  - Base (Button, Input, Card, Badge)
  - Negócio (StoreCard, ProductCard, CategoryCard)
  - Seções (HeroSection, FeaturedProducts, etc)
  - Layout (Header, FloatingActionDock)

/constants             # Constantes e dados
  - theme.js           # Design tokens (ESTE ARQUIVO)
  - mockData.js        # Dados mockados

/hooks                 # Custom hooks
  - useResponsiveDimensions.js
  - useResponsiveLayout.js
```

---

## ✅ Checklist de "UI/UX Fechado"

- [x] Todas as 24 telas implementadas
- [x] Design System documentado e consistente
- [x] Navegação fluida entre todas as páginas
- [x] Componentes reutilizáveis padronizados
- [x] Paleta de cores definida e aplicada
- [x] Tipografia hierárquica consistente
- [x] Spacing system seguido em todas as telas
- [x] Shadows aplicadas consistentemente
- [x] Border radius padronizado
- [x] Todos os links de navegação funcionando
- [x] Profile conectado a todas as sub-páginas
- [x] Estrutura de pastas organizada
- [x] Git ignore configurado
- [x] Workflow funcionando no Replit

---

## 🚫 Regras para Fase de Backend

1. **NÃO modificar estilos visuais** - Apenas conectar dados reais
2. **NÃO alterar paleta de cores** - Usar as definidas acima
3. **NÃO mudar tipografia** - Manter hierarquia estabelecida
4. **NÃO modificar spacing** - Usar sistema de 4px
5. **Substituir dados mock por dados reais** - Manter mesma estrutura visual
6. **Adicionar loading states** - Usando mesmos componentes visuais
7. **Tratar erros** - Com modais/toasts no mesmo estilo visual

---

**Data de Fechamento**: 10 de Novembro de 2025  
**Versão UI**: 1.0.0 LOCKED 🔒
